https://github.com/damian205/comp472_pistachios

1) Open PuzzleGame folder 
2) Run core.py . This wil generate all search and solution files in the root directory
3) To test other combinations of puzzles, add them to one_input file under PuzzleGame directory
4) All result files will be generated in the root directory
5) If you experience any issues with accessing one_input file in the core.py, change line 8 in core.py to reflect a file you want to read:
   with open('PuzzleGame\one_input') as input_file